function X = Zigzagop(Img)
num1=fenkuai(32,Img,1);
num2=fenkuai(32,Img,2);
num3=fenkuai(32,Img,3);
num4=fenkuai(32,Img,4);
num5=fenkuai(32,Img,5);
num6=fenkuai(32,Img,6);
num7=fenkuai(32,Img,7);
num8=fenkuai(32,Img,8);
num9=fenkuai(32,Img,9);
num10=fenkuai(32,Img,10);
num11=fenkuai(32,Img,11);
num12=fenkuai(32,Img,12);
num13=fenkuai(32,Img,13);
num14=fenkuai(32,Img,14);
num15=fenkuai(32,Img,15);
num16=fenkuai(32,Img,16);



ennum1 = Type1(num1);
ennum1 = Type5(ennum1);

 

ennum2 = Type2(num2);
ennum2 = Type6(ennum2);

  

ennum3 = Type3(num3);
ennum3 = Type7(ennum3);



ennum4 = Type4(num4);
ennum4 = Type8(ennum4);



ennum5 = Type5(num5);  
ennum5 = Type1(ennum5);



ennum6 = Type6(num6);
ennum6 = Type2(ennum6);



ennum7 = Type7(num7);
ennum7 = Type3(ennum7);



ennum8 = Type8(num8); 
ennum8 = Type4(ennum8);




ennum9 = Type1(num9);
ennum9 = Type5(ennum9);



ennum10 = Type2(num10);  
ennum10 = Type6(ennum10);

 

ennum11 = Type3(num11);
ennum11 = Type7(ennum11);



ennum12 = Type4(num12);
ennum12 = Type8(ennum12);



ennum13 = Type5(num13);
ennum13 = Type1(ennum13);



ennum14 = Type6(num14);
ennum14 = Type2(ennum14);



ennum15 = Type7(num15);
ennum15 = Type3(ennum15);



ennum16 = Type8(num16);
ennum16 = Type4(ennum16);

X1 = [ennum1,ennum2,ennum3,ennum4,ennum5,ennum6,ennum7,ennum8,ennum9,ennum10,ennum11,ennum12,ennum13,ennum14,ennum15,ennum16];

num1=fenkuai(32,Img,17);
num2=fenkuai(32,Img,18);
num3=fenkuai(32,Img,19);
num4=fenkuai(32,Img,20);
num5=fenkuai(32,Img,21);
num6=fenkuai(32,Img,22);
num7=fenkuai(32,Img,23);
num8=fenkuai(32,Img,24);

num9=fenkuai(32,Img,25);
num10=fenkuai(32,Img,26);
num11=fenkuai(32,Img,27);
num12=fenkuai(32,Img,28);
num13=fenkuai(32,Img,29);
num14=fenkuai(32,Img,30);
num15=fenkuai(32,Img,31);
num16=fenkuai(32,Img,32);


ennum1 = Type1(num1);
ennum1 = Type5(ennum1);

 

ennum2 = Type2(num2);
ennum2 = Type6(ennum2);

  

ennum3 = Type3(num3);
ennum3 = Type7(ennum3);



ennum4 = Type4(num4);
ennum4 = Type8(ennum4);



ennum5 = Type5(num5);  
ennum5 = Type1(ennum5);



ennum6 = Type6(num6);
ennum6 = Type2(ennum6);



ennum7 = Type7(num7);
ennum7 = Type3(ennum7);



ennum8 = Type8(num8); 
ennum8 = Type4(ennum8);




ennum9 = Type1(num9);
ennum9 = Type5(ennum9);



ennum10 = Type2(num10);  
ennum10 = Type6(ennum10);

 

ennum11 = Type3(num11);
ennum11 = Type7(ennum11);



ennum12 = Type4(num12);
ennum12 = Type8(ennum12);



ennum13 = Type5(num13);
ennum13 = Type1(ennum13);



ennum14 = Type6(num14);
ennum14 = Type2(ennum14);



ennum15 = Type7(num15);
ennum15 = Type3(ennum15);



ennum16 = Type8(num16);
ennum16 = Type4(ennum16);

X2 = [ennum1,ennum2,ennum3,ennum4,ennum5,ennum6,ennum7,ennum8,ennum9,ennum10,ennum11,ennum12,ennum13,ennum14,ennum15,ennum16];

num1=fenkuai(32,Img,33);
num2=fenkuai(32,Img,34);   
num3=fenkuai(32,Img,35); 
num4=fenkuai(32,Img,36);
num5=fenkuai(32,Img,37);  
num6=fenkuai(32,Img,38);
num7=fenkuai(32,Img,39);
num8=fenkuai(32,Img,40);  

num9=fenkuai(32,Img,41);
num10=fenkuai(32,Img,42);   
num11=fenkuai(32,Img,43); 
num12=fenkuai(32,Img,44);
num13=fenkuai(32,Img,45);    
num14=fenkuai(32,Img,46);
num15=fenkuai(32,Img,47);
num16=fenkuai(32,Img,48);


ennum1 = Type1(num1);
ennum1 = Type5(ennum1);

 

ennum2 = Type2(num2);
ennum2 = Type6(ennum2);

  

ennum3 = Type3(num3);
ennum3 = Type7(ennum3);



ennum4 = Type4(num4);
ennum4 = Type8(ennum4);



ennum5 = Type5(num5);  
ennum5 = Type1(ennum5);



ennum6 = Type6(num6);
ennum6 = Type2(ennum6);



ennum7 = Type7(num7);
ennum7 = Type3(ennum7);



ennum8 = Type8(num8); 
ennum8 = Type4(ennum8);




ennum9 = Type1(num9);
ennum9 = Type5(ennum9);



ennum10 = Type2(num10);  
ennum10 = Type6(ennum10);

 

ennum11 = Type3(num11);
ennum11 = Type7(ennum11);



ennum12 = Type4(num12);
ennum12 = Type8(ennum12);



ennum13 = Type5(num13);
ennum13 = Type1(ennum13);



ennum14 = Type6(num14);
ennum14 = Type2(ennum14);



ennum15 = Type7(num15);
ennum15 = Type3(ennum15);



ennum16 = Type8(num16);
ennum16 = Type4(ennum16);

X3 = [ennum1,ennum2,ennum3,ennum4,ennum5,ennum6,ennum7,ennum8,ennum9,ennum10,ennum11,ennum12,ennum13,ennum14,ennum15,ennum16];

num1=fenkuai(32,Img,49);
num2=fenkuai(32,Img,50); 
num3=fenkuai(32,Img,51); 
num4=fenkuai(32,Img,52);
num5=fenkuai(32,Img,53);   
num6=fenkuai(32,Img,54);
num7=fenkuai(32,Img,55);
num8=fenkuai(32,Img,56); 

num9=fenkuai(32,Img,57);
num10=fenkuai(32,Img,58);    
num11=fenkuai(32,Img,59);
num12=fenkuai(32,Img,60);
num13=fenkuai(32,Img,61); 
num14=fenkuai(32,Img,62);
num15=fenkuai(32,Img,63);
num16=fenkuai(32,Img,64);

ennum1 = Type1(num1);
ennum1 = Type5(ennum1);

 

ennum2 = Type2(num2);
ennum2 = Type6(ennum2);

  

ennum3 = Type3(num3);
ennum3 = Type7(ennum3);



ennum4 = Type4(num4);
ennum4 = Type8(ennum4);



ennum5 = Type5(num5);  
ennum5 = Type1(ennum5);



ennum6 = Type6(num6);
ennum6 = Type2(ennum6);



ennum7 = Type7(num7);
ennum7 = Type3(ennum7);



ennum8 = Type8(num8); 
ennum8 = Type4(ennum8);




ennum9 = Type1(num9);
ennum9 = Type5(ennum9);



ennum10 = Type2(num10);  
ennum10 = Type6(ennum10);

 

ennum11 = Type3(num11);
ennum11 = Type7(ennum11);



ennum12 = Type4(num12);
ennum12 = Type8(ennum12);



ennum13 = Type5(num13);
ennum13 = Type1(ennum13);



ennum14 = Type6(num14);
ennum14 = Type2(ennum14);



ennum15 = Type7(num15);
ennum15 = Type3(ennum15);



ennum16 = Type8(num16);
ennum16 = Type4(ennum16);

X4 = [ennum1,ennum2,ennum3,ennum4,ennum5,ennum6,ennum7,ennum8,ennum9,ennum10,ennum11,ennum12,ennum13,ennum14,ennum15,ennum16];

num1=fenkuai(32,Img,65);
num2=fenkuai(32,Img,66);   
num3=fenkuai(32,Img,67);
num4=fenkuai(32,Img,68);
num5=fenkuai(32,Img,69);   
num6=fenkuai(32,Img,70);
num7=fenkuai(32,Img,71);
num8=fenkuai(32,Img,72);  

num9=fenkuai(32,Img,73);
num10=fenkuai(32,Img,74);   
num11=fenkuai(32,Img,75);  
num12=fenkuai(32,Img,76);
num13=fenkuai(32,Img,77);  
num14=fenkuai(32,Img,78);
num15=fenkuai(32,Img,79);
num16=fenkuai(32,Img,80);


ennum1 = Type1(num1);
ennum1 = Type5(ennum1);

 

ennum2 = Type2(num2);
ennum2 = Type6(ennum2);

  

ennum3 = Type3(num3);
ennum3 = Type7(ennum3);



ennum4 = Type4(num4);
ennum4 = Type8(ennum4);



ennum5 = Type5(num5);  
ennum5 = Type1(ennum5);



ennum6 = Type6(num6);
ennum6 = Type2(ennum6);



ennum7 = Type7(num7);
ennum7 = Type3(ennum7);



ennum8 = Type8(num8); 
ennum8 = Type4(ennum8);




ennum9 = Type1(num9);
ennum9 = Type5(ennum9);



ennum10 = Type2(num10);  
ennum10 = Type6(ennum10);

 

ennum11 = Type3(num11);
ennum11 = Type7(ennum11);



ennum12 = Type4(num12);
ennum12 = Type8(ennum12);



ennum13 = Type5(num13);
ennum13 = Type1(ennum13);



ennum14 = Type6(num14);
ennum14 = Type2(ennum14);



ennum15 = Type7(num15);
ennum15 = Type3(ennum15);



ennum16 = Type8(num16);
ennum16 = Type4(ennum16);

X5 = [ennum1,ennum2,ennum3,ennum4,ennum5,ennum6,ennum7,ennum8,ennum9,ennum10,ennum11,ennum12,ennum13,ennum14,ennum15,ennum16];


num1=fenkuai(32,Img,81);
num2=fenkuai(32,Img,82);   
num3=fenkuai(32,Img,83); 
num4=fenkuai(32,Img,84);
num5=fenkuai(32,Img,85);   
num6=fenkuai(32,Img,86);
num7=fenkuai(32,Img,87);
num8=fenkuai(32,Img,88);   

num9=fenkuai(32,Img,89);
num10=fenkuai(32,Img,90);  
num11=fenkuai(32,Img,91); 
num12=fenkuai(32,Img,92);
num13=fenkuai(32,Img,93); 
num14=fenkuai(32,Img,94);
num15=fenkuai(32,Img,95);
num16=fenkuai(32,Img,96);

ennum1 = Type1(num1);
ennum1 = Type5(ennum1);

 

ennum2 = Type2(num2);
ennum2 = Type6(ennum2);

  

ennum3 = Type3(num3);
ennum3 = Type7(ennum3);



ennum4 = Type4(num4);
ennum4 = Type8(ennum4);



ennum5 = Type5(num5);  
ennum5 = Type1(ennum5);



ennum6 = Type6(num6);
ennum6 = Type2(ennum6);



ennum7 = Type7(num7);
ennum7 = Type3(ennum7);



ennum8 = Type8(num8); 
ennum8 = Type4(ennum8);




ennum9 = Type1(num9);
ennum9 = Type5(ennum9);



ennum10 = Type2(num10);  
ennum10 = Type6(ennum10);

 

ennum11 = Type3(num11);
ennum11 = Type7(ennum11);



ennum12 = Type4(num12);
ennum12 = Type8(ennum12);



ennum13 = Type5(num13);
ennum13 = Type1(ennum13);



ennum14 = Type6(num14);
ennum14 = Type2(ennum14);



ennum15 = Type7(num15);
ennum15 = Type3(ennum15);



ennum16 = Type8(num16);
ennum16 = Type4(ennum16);

X6 = [ennum1,ennum2,ennum3,ennum4,ennum5,ennum6,ennum7,ennum8,ennum9,ennum10,ennum11,ennum12,ennum13,ennum14,ennum15,ennum16];


num1=fenkuai(32,Img,97);
num2=fenkuai(32,Img,98);   
num3=fenkuai(32,Img,99); 
num4=fenkuai(32,Img,100);
num5=fenkuai(32,Img,101);   
num6=fenkuai(32,Img,102);
num7=fenkuai(32,Img,103);
num8=fenkuai(32,Img,104);   

num9=fenkuai(32,Img,105);
num10=fenkuai(32,Img,106);  
num11=fenkuai(32,Img,107); 
num12=fenkuai(32,Img,108);
num13=fenkuai(32,Img,109); 
num14=fenkuai(32,Img,110);
num15=fenkuai(32,Img,111);
num16=fenkuai(32,Img,112);

ennum1 = Type1(num1);
ennum1 = Type5(ennum1);

 

ennum2 = Type2(num2);
ennum2 = Type6(ennum2);

  

ennum3 = Type3(num3);
ennum3 = Type7(ennum3);



ennum4 = Type4(num4);
ennum4 = Type8(ennum4);



ennum5 = Type5(num5);  
ennum5 = Type1(ennum5);



ennum6 = Type6(num6);
ennum6 = Type2(ennum6);



ennum7 = Type7(num7);
ennum7 = Type3(ennum7);



ennum8 = Type8(num8); 
ennum8 = Type4(ennum8);




ennum9 = Type1(num9);
ennum9 = Type5(ennum9);



ennum10 = Type2(num10);  
ennum10 = Type6(ennum10);

 

ennum11 = Type3(num11);
ennum11 = Type7(ennum11);



ennum12 = Type4(num12);
ennum12 = Type8(ennum12);



ennum13 = Type5(num13);
ennum13 = Type1(ennum13);



ennum14 = Type6(num14);
ennum14 = Type2(ennum14);



ennum15 = Type7(num15);
ennum15 = Type3(ennum15);



ennum16 = Type8(num16);
ennum16 = Type4(ennum16);

X7 = [ennum1,ennum2,ennum3,ennum4,ennum5,ennum6,ennum7,ennum8,ennum9,ennum10,ennum11,ennum12,ennum13,ennum14,ennum15,ennum16];

num1=fenkuai(32,Img,113);
num2=fenkuai(32,Img,114);   
num3=fenkuai(32,Img,115); 
num4=fenkuai(32,Img,116);
num5=fenkuai(32,Img,117);   
num6=fenkuai(32,Img,118);
num7=fenkuai(32,Img,119);
num8=fenkuai(32,Img,120);   

num9=fenkuai(32,Img,121);
num10=fenkuai(32,Img,122);  
num11=fenkuai(32,Img,123); 
num12=fenkuai(32,Img,124);
num13=fenkuai(32,Img,125); 
num14=fenkuai(32,Img,126);
num15=fenkuai(32,Img,127);
num16=fenkuai(32,Img,128);

ennum1 = Type1(num1);
ennum1 = Type5(ennum1);

 

ennum2 = Type2(num2);
ennum2 = Type6(ennum2);

  

ennum3 = Type3(num3);
ennum3 = Type7(ennum3);



ennum4 = Type4(num4);
ennum4 = Type8(ennum4);



ennum5 = Type5(num5);  
ennum5 = Type1(ennum5);



ennum6 = Type6(num6);
ennum6 = Type2(ennum6);



ennum7 = Type7(num7);
ennum7 = Type3(ennum7);



ennum8 = Type8(num8); 
ennum8 = Type4(ennum8);




ennum9 = Type1(num9);
ennum9 = Type5(ennum9);



ennum10 = Type2(num10);  
ennum10 = Type6(ennum10);

 

ennum11 = Type3(num11);
ennum11 = Type7(ennum11);



ennum12 = Type4(num12);
ennum12 = Type8(ennum12);



ennum13 = Type5(num13);
ennum13 = Type1(ennum13);



ennum14 = Type6(num14);
ennum14 = Type2(ennum14);



ennum15 = Type7(num15);
ennum15 = Type3(ennum15);



ennum16 = Type8(num16);
ennum16 = Type4(ennum16);

X8 = [ennum1,ennum2,ennum3,ennum4,ennum5,ennum6,ennum7,ennum8,ennum9,ennum10,ennum11,ennum12,ennum13,ennum14,ennum15,ennum16];

num1=fenkuai(32,Img,129);
num2=fenkuai(32,Img,130);   
num3=fenkuai(32,Img,131); 
num4=fenkuai(32,Img,132);
num5=fenkuai(32,Img,133);   
num6=fenkuai(32,Img,134);
num7=fenkuai(32,Img,135);
num8=fenkuai(32,Img,136);   

num9=fenkuai(32,Img,137);
num10=fenkuai(32,Img,138);  
num11=fenkuai(32,Img,139); 
num12=fenkuai(32,Img,140);
num13=fenkuai(32,Img,141); 
num14=fenkuai(32,Img,142);
num15=fenkuai(32,Img,143);
num16=fenkuai(32,Img,144);

ennum1 = Type1(num1);
ennum1 = Type5(ennum1);

 

ennum2 = Type2(num2);
ennum2 = Type6(ennum2);

  

ennum3 = Type3(num3);
ennum3 = Type7(ennum3);



ennum4 = Type4(num4);
ennum4 = Type8(ennum4);



ennum5 = Type5(num5);  
ennum5 = Type1(ennum5);



ennum6 = Type6(num6);
ennum6 = Type2(ennum6);



ennum7 = Type7(num7);
ennum7 = Type3(ennum7);



ennum8 = Type8(num8); 
ennum8 = Type4(ennum8);




ennum9 = Type1(num9);
ennum9 = Type5(ennum9);



ennum10 = Type2(num10);  
ennum10 = Type6(ennum10);

 

ennum11 = Type3(num11);
ennum11 = Type7(ennum11);



ennum12 = Type4(num12);
ennum12 = Type8(ennum12);



ennum13 = Type5(num13);
ennum13 = Type1(ennum13);



ennum14 = Type6(num14);
ennum14 = Type2(ennum14);



ennum15 = Type7(num15);
ennum15 = Type3(ennum15);



ennum16 = Type8(num16);
ennum16 = Type4(ennum16);

X9 = [ennum1,ennum2,ennum3,ennum4,ennum5,ennum6,ennum7,ennum8,ennum9,ennum10,ennum11,ennum12,ennum13,ennum14,ennum15,ennum16];

num1=fenkuai(32,Img,145);
num2=fenkuai(32,Img,146);   
num3=fenkuai(32,Img,147); 
num4=fenkuai(32,Img,148);
num5=fenkuai(32,Img,149);   
num6=fenkuai(32,Img,150);
num7=fenkuai(32,Img,151);
num8=fenkuai(32,Img,152);   

num9=fenkuai(32,Img,153);
num10=fenkuai(32,Img,154);  
num11=fenkuai(32,Img,155); 
num12=fenkuai(32,Img,156);
num13=fenkuai(32,Img,157); 
num14=fenkuai(32,Img,158);
num15=fenkuai(32,Img,159);
num16=fenkuai(32,Img,160);

ennum1 = Type1(num1);
ennum1 = Type5(ennum1);

 

ennum2 = Type2(num2);
ennum2 = Type6(ennum2);

  

ennum3 = Type3(num3);
ennum3 = Type7(ennum3);



ennum4 = Type4(num4);
ennum4 = Type8(ennum4);



ennum5 = Type5(num5);  
ennum5 = Type1(ennum5);



ennum6 = Type6(num6);
ennum6 = Type2(ennum6);



ennum7 = Type7(num7);
ennum7 = Type3(ennum7);



ennum8 = Type8(num8); 
ennum8 = Type4(ennum8);




ennum9 = Type1(num9);
ennum9 = Type5(ennum9);



ennum10 = Type2(num10);  
ennum10 = Type6(ennum10);

 

ennum11 = Type3(num11);
ennum11 = Type7(ennum11);



ennum12 = Type4(num12);
ennum12 = Type8(ennum12);



ennum13 = Type5(num13);
ennum13 = Type1(ennum13);



ennum14 = Type6(num14);
ennum14 = Type2(ennum14);



ennum15 = Type7(num15);
ennum15 = Type3(ennum15);



ennum16 = Type8(num16);
ennum16 = Type4(ennum16);

X10 = [ennum1,ennum2,ennum3,ennum4,ennum5,ennum6,ennum7,ennum8,ennum9,ennum10,ennum11,ennum12,ennum13,ennum14,ennum15,ennum16];

num1=fenkuai(32,Img,161);
num2=fenkuai(32,Img,162);   
num3=fenkuai(32,Img,163); 
num4=fenkuai(32,Img,164);
num5=fenkuai(32,Img,165);   
num6=fenkuai(32,Img,166);
num7=fenkuai(32,Img,167);
num8=fenkuai(32,Img,168);   

num9=fenkuai(32,Img,169);
num10=fenkuai(32,Img,170);  
num11=fenkuai(32,Img,171); 
num12=fenkuai(32,Img,172);
num13=fenkuai(32,Img,173); 
num14=fenkuai(32,Img,174);
num15=fenkuai(32,Img,175);
num16=fenkuai(32,Img,176);

ennum1 = Type1(num1);
ennum1 = Type5(ennum1);

 

ennum2 = Type2(num2);
ennum2 = Type6(ennum2);

  

ennum3 = Type3(num3);
ennum3 = Type7(ennum3);



ennum4 = Type4(num4);
ennum4 = Type8(ennum4);



ennum5 = Type5(num5);  
ennum5 = Type1(ennum5);



ennum6 = Type6(num6);
ennum6 = Type2(ennum6);



ennum7 = Type7(num7);
ennum7 = Type3(ennum7);



ennum8 = Type8(num8); 
ennum8 = Type4(ennum8);




ennum9 = Type1(num9);
ennum9 = Type5(ennum9);



ennum10 = Type2(num10);  
ennum10 = Type6(ennum10);

 

ennum11 = Type3(num11);
ennum11 = Type7(ennum11);



ennum12 = Type4(num12);
ennum12 = Type8(ennum12);



ennum13 = Type5(num13);
ennum13 = Type1(ennum13);



ennum14 = Type6(num14);
ennum14 = Type2(ennum14);



ennum15 = Type7(num15);
ennum15 = Type3(ennum15);



ennum16 = Type8(num16);
ennum16 = Type4(ennum16);

X11 = [ennum1,ennum2,ennum3,ennum4,ennum5,ennum6,ennum7,ennum8,ennum9,ennum10,ennum11,ennum12,ennum13,ennum14,ennum15,ennum16];

num1=fenkuai(32,Img,177);
num2=fenkuai(32,Img,178);   
num3=fenkuai(32,Img,179); 
num4=fenkuai(32,Img,180);
num5=fenkuai(32,Img,181);   
num6=fenkuai(32,Img,182);
num7=fenkuai(32,Img,183);
num8=fenkuai(32,Img,184);   

num9=fenkuai(32,Img,185);
num10=fenkuai(32,Img,186);  
num11=fenkuai(32,Img,187); 
num12=fenkuai(32,Img,188);
num13=fenkuai(32,Img,189); 
num14=fenkuai(32,Img,190);
num15=fenkuai(32,Img,191);
num16=fenkuai(32,Img,192);

ennum1 = Type1(num1);
ennum1 = Type5(ennum1);

 

ennum2 = Type2(num2);
ennum2 = Type6(ennum2);

  

ennum3 = Type3(num3);
ennum3 = Type7(ennum3);



ennum4 = Type4(num4);
ennum4 = Type8(ennum4);



ennum5 = Type5(num5);  
ennum5 = Type1(ennum5);



ennum6 = Type6(num6);
ennum6 = Type2(ennum6);



ennum7 = Type7(num7);
ennum7 = Type3(ennum7);



ennum8 = Type8(num8); 
ennum8 = Type4(ennum8);




ennum9 = Type1(num9);
ennum9 = Type5(ennum9);



ennum10 = Type2(num10);  
ennum10 = Type6(ennum10);

 

ennum11 = Type3(num11);
ennum11 = Type7(ennum11);



ennum12 = Type4(num12);
ennum12 = Type8(ennum12);



ennum13 = Type5(num13);
ennum13 = Type1(ennum13);



ennum14 = Type6(num14);
ennum14 = Type2(ennum14);



ennum15 = Type7(num15);
ennum15 = Type3(ennum15);



ennum16 = Type8(num16);
ennum16 = Type4(ennum16);

X12 = [ennum1,ennum2,ennum3,ennum4,ennum5,ennum6,ennum7,ennum8,ennum9,ennum10,ennum11,ennum12,ennum13,ennum14,ennum15,ennum16];

num1=fenkuai(32,Img,193);
num2=fenkuai(32,Img,194);   
num3=fenkuai(32,Img,195); 
num4=fenkuai(32,Img,196);
num5=fenkuai(32,Img,197);   
num6=fenkuai(32,Img,198);
num7=fenkuai(32,Img,199);
num8=fenkuai(32,Img,200);   

num9=fenkuai(32,Img,201);
num10=fenkuai(32,Img,202);  
num11=fenkuai(32,Img,203); 
num12=fenkuai(32,Img,204);
num13=fenkuai(32,Img,205); 
num14=fenkuai(32,Img,206);
num15=fenkuai(32,Img,207);
num16=fenkuai(32,Img,208);

ennum1 = Type1(num1);
ennum1 = Type5(ennum1);

 

ennum2 = Type2(num2);
ennum2 = Type6(ennum2);

  

ennum3 = Type3(num3);
ennum3 = Type7(ennum3);



ennum4 = Type4(num4);
ennum4 = Type8(ennum4);



ennum5 = Type5(num5);  
ennum5 = Type1(ennum5);



ennum6 = Type6(num6);
ennum6 = Type2(ennum6);



ennum7 = Type7(num7);
ennum7 = Type3(ennum7);



ennum8 = Type8(num8); 
ennum8 = Type4(ennum8);




ennum9 = Type1(num9);
ennum9 = Type5(ennum9);



ennum10 = Type2(num10);  
ennum10 = Type6(ennum10);

 

ennum11 = Type3(num11);
ennum11 = Type7(ennum11);



ennum12 = Type4(num12);
ennum12 = Type8(ennum12);



ennum13 = Type5(num13);
ennum13 = Type1(ennum13);



ennum14 = Type6(num14);
ennum14 = Type2(ennum14);



ennum15 = Type7(num15);
ennum15 = Type3(ennum15);



ennum16 = Type8(num16);
ennum16 = Type4(ennum16);

X13 = [ennum1,ennum2,ennum3,ennum4,ennum5,ennum6,ennum7,ennum8,ennum9,ennum10,ennum11,ennum12,ennum13,ennum14,ennum15,ennum16];

num1=fenkuai(32,Img,209);
num2=fenkuai(32,Img,210);   
num3=fenkuai(32,Img,211); 
num4=fenkuai(32,Img,212);
num5=fenkuai(32,Img,213);   
num6=fenkuai(32,Img,214);
num7=fenkuai(32,Img,215);
num8=fenkuai(32,Img,216);   

num9=fenkuai(32,Img,217);
num10=fenkuai(32,Img,218);  
num11=fenkuai(32,Img,219); 
num12=fenkuai(32,Img,220);
num13=fenkuai(32,Img,221); 
num14=fenkuai(32,Img,222);
num15=fenkuai(32,Img,223);
num16=fenkuai(32,Img,224);

ennum1 = Type1(num1);
ennum1 = Type5(ennum1);

 

ennum2 = Type2(num2);
ennum2 = Type6(ennum2);

  

ennum3 = Type3(num3);
ennum3 = Type7(ennum3);



ennum4 = Type4(num4);
ennum4 = Type8(ennum4);



ennum5 = Type5(num5);  
ennum5 = Type1(ennum5);



ennum6 = Type6(num6);
ennum6 = Type2(ennum6);



ennum7 = Type7(num7);
ennum7 = Type3(ennum7);



ennum8 = Type8(num8); 
ennum8 = Type4(ennum8);




ennum9 = Type1(num9);
ennum9 = Type5(ennum9);



ennum10 = Type2(num10);  
ennum10 = Type6(ennum10);

 

ennum11 = Type3(num11);
ennum11 = Type7(ennum11);



ennum12 = Type4(num12);
ennum12 = Type8(ennum12);



ennum13 = Type5(num13);
ennum13 = Type1(ennum13);



ennum14 = Type6(num14);
ennum14 = Type2(ennum14);



ennum15 = Type7(num15);
ennum15 = Type3(ennum15);



ennum16 = Type8(num16);
ennum16 = Type4(ennum16);

X14 = [ennum1,ennum2,ennum3,ennum4,ennum5,ennum6,ennum7,ennum8,ennum9,ennum10,ennum11,ennum12,ennum13,ennum14,ennum15,ennum16];


num1=fenkuai(32,Img,225);
num2=fenkuai(32,Img,226);   
num3=fenkuai(32,Img,227); 
num4=fenkuai(32,Img,228);
num5=fenkuai(32,Img,229);   
num6=fenkuai(32,Img,230);
num7=fenkuai(32,Img,231);
num8=fenkuai(32,Img,232);   

num9=fenkuai(32,Img,233);
num10=fenkuai(32,Img,234);  
num11=fenkuai(32,Img,235); 
num12=fenkuai(32,Img,236);
num13=fenkuai(32,Img,237); 
num14=fenkuai(32,Img,238);
num15=fenkuai(32,Img,239);
num16=fenkuai(32,Img,240);

ennum1 = Type1(num1);
ennum1 = Type5(ennum1);

 

ennum2 = Type2(num2);
ennum2 = Type6(ennum2);

  

ennum3 = Type3(num3);
ennum3 = Type7(ennum3);



ennum4 = Type4(num4);
ennum4 = Type8(ennum4);



ennum5 = Type5(num5);  
ennum5 = Type1(ennum5);



ennum6 = Type6(num6);
ennum6 = Type2(ennum6);



ennum7 = Type7(num7);
ennum7 = Type3(ennum7);



ennum8 = Type8(num8); 
ennum8 = Type4(ennum8);




ennum9 = Type1(num9);
ennum9 = Type5(ennum9);



ennum10 = Type2(num10);  
ennum10 = Type6(ennum10);

 

ennum11 = Type3(num11);
ennum11 = Type7(ennum11);



ennum12 = Type4(num12);
ennum12 = Type8(ennum12);



ennum13 = Type5(num13);
ennum13 = Type1(ennum13);



ennum14 = Type6(num14);
ennum14 = Type2(ennum14);



ennum15 = Type7(num15);
ennum15 = Type3(ennum15);



ennum16 = Type8(num16);
ennum16 = Type4(ennum16);

X15 = [ennum1,ennum2,ennum3,ennum4,ennum5,ennum6,ennum7,ennum8,ennum9,ennum10,ennum11,ennum12,ennum13,ennum14,ennum15,ennum16];

num1=fenkuai(32,Img,241);
num2=fenkuai(32,Img,242);   
num3=fenkuai(32,Img,243); 
num4=fenkuai(32,Img,244);
num5=fenkuai(32,Img,245);   
num6=fenkuai(32,Img,246);
num7=fenkuai(32,Img,247);
num8=fenkuai(32,Img,248);   

num9=fenkuai(32,Img,249);
num10=fenkuai(32,Img,250);  
num11=fenkuai(32,Img,251); 
num12=fenkuai(32,Img,252);
num13=fenkuai(32,Img,253); 
num14=fenkuai(32,Img,254);
num15=fenkuai(32,Img,255);
num16=fenkuai(32,Img,256);

ennum1 = Type1(num1);
ennum1 = Type5(ennum1);

 

ennum2 = Type2(num2);
ennum2 = Type6(ennum2);

  

ennum3 = Type3(num3);
ennum3 = Type7(ennum3);



ennum4 = Type4(num4);
ennum4 = Type8(ennum4);



ennum5 = Type5(num5);  
ennum5 = Type1(ennum5);



ennum6 = Type6(num6);
ennum6 = Type2(ennum6);



ennum7 = Type7(num7);
ennum7 = Type3(ennum7);



ennum8 = Type8(num8); 
ennum8 = Type4(ennum8);




ennum9 = Type1(num9);
ennum9 = Type5(ennum9);



ennum10 = Type2(num10);  
ennum10 = Type6(ennum10);

 

ennum11 = Type3(num11);
ennum11 = Type7(ennum11);



ennum12 = Type4(num12);
ennum12 = Type8(ennum12);



ennum13 = Type5(num13);
ennum13 = Type1(ennum13);



ennum14 = Type6(num14);
ennum14 = Type2(ennum14);



ennum15 = Type7(num15);
ennum15 = Type3(ennum15);



ennum16 = Type8(num16);
ennum16 = Type4(ennum16);


X16 = [ennum1,ennum2,ennum3,ennum4,ennum5,ennum6,ennum7,ennum8,ennum9,ennum10,ennum11,ennum12,ennum13,ennum14,ennum15,ennum16];

X = [X1;X2;X3;X4;X5;X6;X7;X8;X9;X10;X11;X12;X13;X14;X15;X16];

X = Type1(X);
X = Type5(X);
%imwrite(X,'en.bmp');
%imshow(X);
end

